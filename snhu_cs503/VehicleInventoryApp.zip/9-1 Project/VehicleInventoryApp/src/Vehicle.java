/**
 * Abstract model class for a vehicle in inventory.
 */
public abstract class Vehicle {

    // Private fields
    private int id;
    private String name;
    private double price;
    private boolean inStock;

    /**
     * Public constructor.
     *
     * @param id      Unique vehicle id
     * @param name    Vehicle name
     * @param price   Vehicle price
     * @param inStock Whether the vehicle is currently in stock
     */
    public Vehicle(int id, String name, double price, boolean inStock) {
        this.id = id;
        this.name = name;
        this.price = price;
        this.inStock = inStock;
    }

    public void setId(int id) {
        this.id = id;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public void setInStock(boolean inStock) {
        this.inStock = inStock;
    }

    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public double getPrice() {
        return price;
    }

    public boolean isInStock() {
        return inStock;
    }


    /**
     * Returns a multi-line String containing the common Vehicle fields.
     * Subclasses override toString() and call super.toString() to include these common fields
     * plus their subtype-specific fields.
     */
    @Override
    public String toString() {
        return "ID: " + id + "\n"
                + "Name: " + name + "\n"
                + "Price: " + price + "\n"
                + "In Stock: " + inStock;
    }

}