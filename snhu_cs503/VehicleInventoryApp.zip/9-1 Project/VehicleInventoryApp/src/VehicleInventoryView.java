import java.util.List;

/**
 * View class responsible for all user-facing text output and user prompts.
 * The view "has a" VehicleInventoryUI instance.
 */
public class VehicleInventoryView {

    private final VehicleInventoryUI ui;

    public VehicleInventoryView(VehicleInventoryUI ui) {
        this.ui = ui;
    }

    public void displayMainMenu() {
        ui.output("Main Menu");
        ui.output("1: Display All Vehicles.");
        ui.output("2: Add Vehicle.");
        ui.output("3: View Vehicle.");
        ui.output("4: Remove Vehicle.");
        ui.output("5: Exit.");
    }

    public void displayMessage(String message) {
        ui.output(message);
    }

    public void displayAllVehicles(List<Vehicle> vehicles) {
        ui.output(String.format("%-5s |%-15s |%-10s |%-10s", "ID", "Name", "Price", "In Stock"));

        // If the list is empty, the requirement/demo shows only the column names (no rows).
        for (Vehicle v : vehicles) {
            // Basic list display shows only the shared Vehicle fields.
            String row = String.format("%-5d  %-15s  %-10.2f  %-10b",
                    v.getId(),
                    v.getName(),
                    v.getPrice(),
                    v.isInStock());
            ui.output(row);
        }
    }

        public void displayVehicleInfo(Vehicle vehicle) {
        // Each Vehicle subtype overrides toString() to include its details.
        ui.output(vehicle.toString());
    }


    /**
     * Reads the main menu choice.
     * Validation: Show "Invalid choice!" indefinitely until the user enters 1-5.
     */
        public int enterMenuChoice(String prompt) {
        // Validation: main menu choice must continue prompting until a valid integer is entered.
        while (true) {
            String line = ui.inputString(prompt).trim();

            // Simple validation to avoid throwing/catching exceptions for menu input.
            // Only accept digits.
            if (line.matches("\\d+")) {
                return Integer.parseInt(line);
            }

            ui.output("");
            ui.output("Invalid choice!");
            ui.output("");
        }
    }


    /**
     * Prompts the user for a valid vehicle type (boat, car, or plane).
     * Validation: Show "Invalid choice!" indefinitely until the user enters boat, car, or plane.
     */
    public String enterVehicleType(String prompt) {
        while (true) {
            String type = ui.inputString(prompt).trim().toLowerCase();

            if (type.equals("boat") || type.equals("car") || type.equals("plane")) {
                return type;
            }

            ui.output("Invalid choice!");
        }
    }

    /**
     * Prompts the user for a vehicle id.
     * Validation: If the value is not a number / int, shut down (controller handles the message & exit).
     */
        public int enterVehicleId(String prompt) {
        return ui.inputInt(prompt);
    }


    /**
     * Creates a new Vehicle by collecting data from the user.
     * This method acts like a small "factory method".
     * Validation: If id/price/inStock is entered with the wrong type, shut down (controller handles).
     */
    public Vehicle enterNewVehicleData(String vehicleType) {
        // This method is expected to delegate input directly to the UI layer by calling ui.inputString / ui.inputDouble / ui.inputBoolean.

        int id = ui.inputInt("Enter id: ");
        String name = ui.inputString("Enter name: ");
        double price = ui.inputDouble("Enter price: ");
        boolean inStock = ui.inputBoolean("In stock? (Enter true or false): ");

        return createVehicleFromInputs(vehicleType, id, name, price, inStock);
    }

    /**
     * Overload used by the Controller so it can optionally check for duplicate IDs before asking the user for the rest of the vehicle data.
     */
    public Vehicle enterNewVehicleData(String vehicleType, int id) {
        String name = ui.inputString("Enter name: ");
        double price = ui.inputDouble("Enter price: ");
        boolean inStock = ui.inputBoolean("In stock? (Enter true or false): ");

        return createVehicleFromInputs(vehicleType, id, name, price, inStock);
    }

    /**
     * Shared creation logic used by both enterNewVehicleData(...) overloads.
     * Prompts for the type-specific attribute and returns the correct subtype.
     */
    private Vehicle createVehicleFromInputs(String vehicleType, int id, String name, double price, boolean inStock) {
        switch (vehicleType.toLowerCase()) {
            case "boat":
                double hullSize = ui.inputDouble("Enter hull size: ");
                return new Boat(id, name, price, inStock, hullSize);

            case "car":
                boolean awd = ui.inputBoolean("All Wheel Drive? (Enter true or false): ");
                return new Car(id, name, price, inStock, awd);

            case "plane":
                boolean twin = ui.inputBoolean("Twin Engine? (Enter true or false): ");
                return new Plane(id, name, price, inStock, twin);

            default:
                // Should be unreachable because enterVehicleType validates before this.
                throw new IllegalArgumentException("Unsupported vehicle type: " + vehicleType);
        }
    }
}
