import java.util.Scanner;

/**
 * Console-based implementation of VehicleInventoryUI.
 * This class simply reads input and attempts to parse it.
 * Any parsing exceptions (NumberFormatException / IllegalArgumentException) are handled later by the Controller
 */
public class VehicleInventoryUIImpl implements VehicleInventoryUI {

    private final Scanner keyboard = new Scanner(System.in);

    @Override
    public void output(String message) {
        System.out.println(message);
    }

    @Override
    public int inputInt(String prompt) {
        System.out.print(prompt);
        String line = keyboard.nextLine().trim();

        // No try/catch here: let NumberFormatException propagate to the Controller.
        return Integer.parseInt(line);
    }

    @Override
    public String inputString(String prompt) {
        System.out.print(prompt);
        return keyboard.nextLine();
    }

    @Override
    public double inputDouble(String prompt) {
        System.out.print(prompt);
        String line = keyboard.nextLine().trim();

        // No try/catch here: let NumberFormatException propagate to the Controller.
        return Double.parseDouble(line);
    }

    @Override
    public boolean inputBoolean(String prompt) {
        System.out.print(prompt);
        String line = keyboard.nextLine().trim();

        // Only accept the literal values true/false.
        if (line.equalsIgnoreCase("true")) {
            return true;
        }
        if (line.equalsIgnoreCase("false")) {
            return false;
        }

        // No try/catch here: let an exception propagate to the Controller.
        throw new IllegalArgumentException("Invalid boolean input: " + line);
    }
}
