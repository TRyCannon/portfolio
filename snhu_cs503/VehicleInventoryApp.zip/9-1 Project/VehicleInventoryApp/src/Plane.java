/**
 * Plane is a concrete Vehicle subclass (inherits from Vehicle).
 */
public class Plane extends Vehicle {

    private boolean twinEngine;

    public Plane(int id, String name, double price, boolean inStock, boolean twinEngine) {
        super(id, name, price, inStock);
        this.twinEngine = twinEngine;
    }

    public void setTwinEngine(boolean twinEngine) {
        this.twinEngine = twinEngine;
    }

    public boolean isTwinEngine() {
        return twinEngine;
    }


    @Override
    public String toString() {
        return super.toString() + "\n"
                + "Twin Engine: " + twinEngine;
    }

}