/**
 * Boat is a concrete Vehicle subclass (inherits from Vehicle).
 */
public class Boat extends Vehicle {

    private double hullSize;

    public Boat(int id, String name, double price, boolean inStock, double hullSize) {
        super(id, name, price, inStock);
        this.hullSize = hullSize;
    }

    public void setHullSize(double hullSize) {
        this.hullSize = hullSize;
    }

    public double getHullSize() {
        return hullSize;
    }


    @Override
    public String toString() {
        return super.toString() + "\n"
                + "Hull Size: " + hullSize;
    }

}