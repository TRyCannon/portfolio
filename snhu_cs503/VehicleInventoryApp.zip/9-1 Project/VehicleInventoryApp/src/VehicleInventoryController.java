/**
 * Controller class for the Vehicle Inventory application.
 * It coordinates between the view (user interaction) and the DAO (data storage)
 */
public class VehicleInventoryController {

    private final VehicleInventoryView view;
    private final VehicleInventoryDao dao;

    public VehicleInventoryController(VehicleInventoryView view, VehicleInventoryDao dao) {
        this.view = view;
        this.dao = dao;
    }

    public void start() {
        // Main application loop (runs indefinitely until Exit or a fatal exception occurs)
        while (true) {
            view.displayMainMenu();
            int choice = view.enterMenuChoice("Enter a choice: ");

            // Validation: Show an error message indefinitely until choice is 1-5.
            if (choice < 1 || choice > 5) {
                view.displayMessage("");
                view.displayMessage("Invalid choice!");
                view.displayMessage("");
                continue;
            }

            switch (choice) {
                case 1:
                    listAllVehicles();
                    break;
                case 2:
                    createVehicle();
                    break;
                case 3:
                    findVehicle();
                    break;
                case 4:
                    deleteVehicle();
                    break;
                case 5:
                    shutDown("Good Bye!");
                    return; // (unreachable after System.exit, but keeps code clear)
                default:
                    // This default is unreachable because of the validation above.
                    break;
            }

            // Extra blank line to make output more readable.
            view.displayMessage("");
        }
    }

    public void listAllVehicles() {
        view.displayMessage("");
        view.displayMessage("Display Vehicles Menu:");
        view.displayAllVehicles(dao.getAllVehicles());
    }

    public void createVehicle() {
        try {
            view.displayMessage("");
            view.displayMessage("Add Vehicle Menu:");

            // Input retrieval for creating a vehicle should be delegated to the View layer.
            // The Controller coordinates the flow, but it should not perform raw input operations.
            String type = view.enterVehicleType("Enter vehicle type (boat, car, or plane): ");

            // Retrieve ID separately so we can check for duplicates before asking for the rest of the data.
            int id = view.enterVehicleId("Enter id: ");

            // Validation requirement: if the vehicle id already exists, prevent adding and return to menu.
            if (dao.getVehicle(id) != null) {
                view.displayMessage("");
                view.displayMessage("Vehicle ID already exists! Please try again!");
                return;
            }

            // Now gather remaining data and create the specific Vehicle subtype.
            Vehicle newVehicle = view.enterNewVehicleData(type, id);

            dao.addVehicle(newVehicle);
        } catch (RuntimeException ex) {
            // Validation: show error message once and shut down after handling exception.
            view.displayMessage("");
            shutDown("Vehicle Creation failed!\nSystem shutting down!");
        }
    }

    public void findVehicle() {
        try {
            view.displayMessage("");
            view.displayMessage("View Vehicle Menu:");
            int id = view.enterVehicleId("Enter Vehicle ID: ");

            Vehicle found = dao.getVehicle(id);
            if (found == null) {
                view.displayMessage("Vehicle not found!");
                return;
            }

            view.displayMessage("Vehicle found!");
            view.displayVehicleInfo(found);
        } catch (RuntimeException ex) {
            // Validation: show error message once and shut down after handling exception.
            view.displayMessage("");
            shutDown("Vehicle Search failed!\nSystem shutting down!");
        }
    }

        public void deleteVehicle() {
        try {
            view.displayMessage("");
            view.displayMessage("Remove Vehicle Menu:");
            int id = view.enterVehicleId("Enter Vehicle ID: ");

            Vehicle found = dao.getVehicle(id);
            if (found == null) {
                view.displayMessage("Vehicle not found!");
                return;
            }

            // Deletion check: verify whether the DAO actually removed the Vehicle.
            boolean removed = dao.removeVehicle(found);
            if (removed) {
                view.displayMessage("Vehicle removed!");
            } else {
                view.displayMessage("Vehicle could not be removed!");
            }
        } catch (RuntimeException ex) {
            // Validation: show error message once and shut down after handling exception.
            view.displayMessage("");
            shutDown("Vehicle Deletion failed!\nSystem shutting down!");
        }
    }


    public void shutDown(String message) {
        view.displayMessage(message);
        System.exit(0);
    }
}
