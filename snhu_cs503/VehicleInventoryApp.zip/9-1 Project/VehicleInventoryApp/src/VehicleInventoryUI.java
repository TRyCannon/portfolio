/**
 * UI interface for console input/output.
 */
public interface VehicleInventoryUI {

    void output(String message);

    int inputInt(String prompt);

    String inputString(String prompt);

    double inputDouble(String prompt);

    boolean inputBoolean(String prompt);
}
