import java.util.ArrayList;
import java.util.List;

/**
 * In-memory DAO implementation backed by an ArrayList.
 * This DAO uses an ArrayList for in-memory storage.
 */
public class VehicleInventoryDaoImpl implements VehicleInventoryDao {

    // This list should NOT be static. Each DAO instance should manage its own inventory.
    // Using a static list can cause data to "leak" across different DAO instances and
    // across unit tests, producing incorrect sizes/counts.
    private final List<Vehicle> vehicles = new ArrayList<>();

    @Override
    public List<Vehicle> getAllVehicles() {
        // Return the vehicles list.
        return vehicles;
    }

    @Override
    public void addVehicle(Vehicle vehicle) {
        // Data integrity check: do not allow duplicate IDs.
        if (vehicle == null) {
            return;
        }
        if (getVehicle(vehicle.getId()) != null) {
            return;
        }
        vehicles.add(vehicle);
    }

    @Override
    public Vehicle getVehicle(int id) {
        for (Vehicle v : vehicles) {
            if (v.getId() == id) {
                return v;
            }
        }
        return null;
    }

    @Override
    public boolean removeVehicle(Vehicle vehicle) {
        // Validation/data layer defense:Remove based on the Vehicle's id instead of relying on object reference equality.
        // This makes the DAO robust even if the caller passes a different instance representing the same Vehicle id.
        if (vehicle == null) {
            return false;
        }

        for (int i = 0; i < vehicles.size(); i++) {
            if (vehicles.get(i).getId() == vehicle.getId()) {
                vehicles.remove(i);
                return true;
            }
        }

        return false;
    }
}
