/**
 * Car is a concrete Vehicle subclass (inherits from Vehicle).
 */
public class Car extends Vehicle {

    private boolean awd;

    public Car(int id, String name, double price, boolean inStock, boolean awd) {
        super(id, name, price, inStock);
        this.awd = awd;
    }

    public void setAwd(boolean awd) {
        this.awd = awd;
    }

    public boolean isAwd() {
        return awd;
    }


    @Override
    public String toString() {
        return super.toString() + "\n"
                + "All Wheel Drive: " + awd;
    }

}