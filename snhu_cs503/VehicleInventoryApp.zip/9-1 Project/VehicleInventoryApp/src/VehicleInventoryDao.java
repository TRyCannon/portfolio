import java.util.List;

/**
 * DAO interface for accessing / managing vehicle inventory in memory.
 */
public interface VehicleInventoryDao {

    List<Vehicle> getAllVehicles();

    void addVehicle(Vehicle vehicle);

    Vehicle getVehicle(int id);

    boolean removeVehicle(Vehicle vehicle);
}
