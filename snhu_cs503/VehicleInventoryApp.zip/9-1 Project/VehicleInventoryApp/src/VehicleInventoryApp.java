/**
 * Entry point for the Vehicle Inventory Management command prompt application.
 */
public class VehicleInventoryApp {

    public static void main(String[] args) {
        VehicleInventoryUI ui = new VehicleInventoryUIImpl();
        VehicleInventoryView view = new VehicleInventoryView(ui);
        VehicleInventoryDao dao = new VehicleInventoryDaoImpl();

        VehicleInventoryController controller = new VehicleInventoryController(view, dao);
        controller.start();
    }
}
