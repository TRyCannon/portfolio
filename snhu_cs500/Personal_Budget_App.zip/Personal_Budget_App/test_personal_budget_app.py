import os

# Prevent matplotlib from trying to open a GUI during unit tests
os.environ.setdefault("MPLBACKEND", "Agg")

import json
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

import personal_budget_app


class TestBudgetApp(unittest.TestCase):
    """Unit tests for the CS 500 Scenario 1 Budgeting Application."""

    def test_add_expense_and_total(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            data_file = Path(tmp) / "budget_data.json"

            with patch.object(personal_budget_app, "DATA_FILE", data_file):
                mgr = personal_budget_app.BudgetManager()

                mgr.set_monthly_income(5000.00)
                mgr.set_savings_goal(500.00)

                mgr.add_expense("Food", 25.50, "Lunch", "2026-01-10")
                mgr.add_expense("Food", 10.00, "Coffee", "2026-01-10")
                mgr.add_expense("Housing", 1000.00, "Rent", "2026-01-01")

                self.assertAlmostEqual(mgr.total_expenses(), 1035.50, places=2)
                self.assertIn("Food", mgr.categories)
                self.assertIn("Housing", mgr.categories)

    def test_month_and_date_range_filters(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            data_file = Path(tmp) / "budget_data.json"

            with patch.object(personal_budget_app, "DATA_FILE", data_file):
                mgr = personal_budget_app.BudgetManager()

                mgr.add_expense("Transport", 40.00, "Gas", "2026-01-05")
                mgr.add_expense("Transport", 60.00, "Gas", "2026-02-05")
                mgr.add_expense("Food", 20.00, "Groceries", "2026-01-15")

                jan_total = mgr.total_expenses(month="2026-01")
                self.assertAlmostEqual(jan_total, 60.00, places=2)

                feb_total = mgr.total_expenses(date_range=("2026-02-01", "2026-02-28"))
                self.assertAlmostEqual(feb_total, 60.00, places=2)

    def test_progress_toward_goal(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            data_file = Path(tmp) / "budget_data.json"

            with patch.object(personal_budget_app, "DATA_FILE", data_file):
                mgr = personal_budget_app.BudgetManager()

                mgr.set_monthly_income(3000.00)
                mgr.set_savings_goal(500.00)
                mgr.add_expense("Utilities", 2700.00, "Bills", "2026-01-02")

                info = mgr.progress_toward_goal(month="2026-01")
                self.assertFalse(info["on_track"])
                self.assertAlmostEqual(float(info["savings"]), 300.00, places=2)
                self.assertAlmostEqual(float(info["remaining_needed"]), 200.00, places=2)

    def test_custom_income_range_savings(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            data_file = Path(tmp) / "budget_data.json"

            with patch.object(personal_budget_app, "DATA_FILE", data_file):
                mgr = personal_budget_app.BudgetManager()

                mgr.add_custom_income(1000.00, "2026-01-01", "2026-01-15")
                mgr.add_custom_income(500.00, "2026-02-01", "2026-02-28")

                # Range overlaps only the first income period
                income = mgr.income_for_range("2026-01-10", "2026-01-20")
                self.assertAlmostEqual(income, 1000.00, places=2)

    def test_save_and_load_data(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            data_file = Path(tmp) / "budget_data.json"

            with patch.object(personal_budget_app, "DATA_FILE", data_file):
                mgr1 = personal_budget_app.BudgetManager()
                mgr1.set_monthly_income(4500.00)
                mgr1.set_savings_goal(750.00)
                mgr1.add_custom_income(1000.00, "2026-01-01", "2026-01-15")
                mgr1.add_expense("Food", 99.99, "Groceries", "2026-01-03")
                mgr1.save_data()

                # Load into a new manager instance
                mgr2 = personal_budget_app.BudgetManager()

                self.assertAlmostEqual(mgr2.monthly_income, 4500.00, places=2)
                self.assertAlmostEqual(mgr2.savings_goal, 750.00, places=2)
                self.assertEqual(len(mgr2.custom_incomes), 1)
                self.assertIn("Food", mgr2.categories)
                self.assertAlmostEqual(mgr2.total_expenses(month="2026-01"), 99.99, places=2)

                raw = json.loads(data_file.read_text(encoding="utf-8"))
                self.assertIn("categories", raw)
                self.assertIn("custom_incomes", raw)

    def test_get_valid_float_validation(self) -> None:
        # First input is non-numeric, second is negative, third is valid.
        # Patch print() so the unit test output stays clean.
        with patch("builtins.print"):
            with patch("builtins.input", side_effect=["abc", "-5", "12.34"]):
                value = personal_budget_app.get_valid_float("Enter: $", min_value=0.0)
        self.assertAlmostEqual(value, 12.34, places=2)

    def test_get_valid_date_validation(self) -> None:
        # Patch print() so the unit test output stays clean.
        with patch("builtins.print"):
            with patch("builtins.input", side_effect=["2026/01/01", "2026-01-01"]):
                value = personal_budget_app.get_valid_date("Enter date: ")
        self.assertEqual(value, "2026-01-01")


if __name__ == "__main__":
    unittest.main(verbosity=2)
