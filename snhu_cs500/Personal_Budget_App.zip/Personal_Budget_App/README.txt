Overview
--------
This budgeting application allows a user to:
- Set income for a monthly timeframe and a custom timeframe
- Set a monthly savings goal
- Add categorized expenses with description and date
- View total expenses for a month, custom period, or all time
- View savings for a month (using monthly income) or custom period (using custom incomes)
- Visualize expenses by category with pie charts using matplotlib

How to run the application
-------------------------
1) Install requirements (if needed):
   pip install -r requirements.txt

2) Run the application:
   python personal_budget_app.py

Data persistence
----------------
The application saves and loads budgeting data using a JSON file. When the application starts, it attempts to load previously saved data.
When you choose "Save and Exit" from the menu, the application writes the current budget data to the JSON file.

How to run unit tests
---------------------
From the project folder, run:
   python -m unittest -v

Files included
--------------
- personal_budget_app.py
- test_personal_budget_app.py
- Process_Summary.docx
- personal_budget_app_flowchart.vsdx
- requirements.txt
