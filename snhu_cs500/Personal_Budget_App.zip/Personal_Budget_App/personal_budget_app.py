"""
This budgeting application allows a user to:
- Set income for a monthly timeframe and a custom timeframe
- Set a monthly savings goal
- Add categorized expenses with description and date
- View total expenses for a month, custom period, or all time
- View savings for a month (using monthly income) or custom period (using custom incomes)
- Visualize expenses by category with pie charts

Data is persisted to a local JSON file so the user can resume later.
"""

import json
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Optional, Tuple

import matplotlib.pyplot as plt

DATA_FILE = Path(__file__).with_name("budget_data.json")
DATE_FMT = "%Y-%m-%d"


# Data model (OOP).

class Expense:
    """Represents a single expense entry."""

    def __init__(self: "Expense", category: str, amount: float, description: str, date: str) -> None:
        self.category = category
        self.amount = amount
        self.description = description
        # The date is stored in YYYY-MM-DD format.
        self.date = date

    def to_dict(self: "Expense") -> Dict[str, object]:
        """Convert this Expense to a dictionary for JSON storage."""
        return {
            "category": self.category,
            "amount": self.amount,
            "description": self.description,
            "date": self.date,
        }

    @staticmethod
    def from_dict(data: Dict[str, object]) -> "Expense":
        """Create an Expense from a dictionary (loaded from JSON)."""
        return Expense(
            category=str(data["category"]),
            amount=float(data["amount"]),
            description=str(data["description"]),
            date=str(data["date"]),
        )


class IncomePeriod:
    """Represents income for a custom time period (inclusive date range)."""

    def __init__(self: "IncomePeriod", amount: float, start_date: str, end_date: str) -> None:
        self.amount = amount
        # Dates are stored in YYYY-MM-DD format.
        self.start_date = start_date
        self.end_date = end_date

    def to_dict(self: "IncomePeriod") -> Dict[str, object]:
        """Convert this IncomePeriod to a dictionary for JSON storage."""
        return {
            "amount": self.amount,
            "start_date": self.start_date,
            "end_date": self.end_date,
        }

    @staticmethod
    def from_dict(data: Dict[str, object]) -> "IncomePeriod":
        """Create an IncomePeriod from a dictionary (loaded from JSON)."""
        return IncomePeriod(
            amount=float(data["amount"]),
            start_date=str(data["start_date"]),
            end_date=str(data["end_date"]),
        )


class BudgetCategory:
    """Tracks expenses for one category."""

    def __init__(self: "BudgetCategory", name: str) -> None:
        self.name = name
        self.expenses: List[Expense] = []

    def add_expense(self: "BudgetCategory", expense: Expense) -> None:
        self.expenses.append(expense)

    def total_expenses(
        self: "BudgetCategory",
        month: Optional[str] = None,
        date_range: Optional[Tuple[str, str]] = None,
    ) -> float:
        """
        Return total expenses for this category, optionally filtered.

        Args:
            month: Optional month filter in 'YYYY-MM' format.
            date_range: Optional (start_date, end_date) inclusive, in 'YYYY-MM-DD'.
        """
        if month is None and date_range is None:
            return sum(e.amount for e in self.expenses)

        if month is not None:
            return sum(e.amount for e in self.expenses if e.date.startswith(month))

        start, end = date_range
        start_dt = datetime.strptime(start, DATE_FMT).date()
        end_dt = datetime.strptime(end, DATE_FMT).date()

        total = 0.0
        for e in self.expenses:
            e_dt = datetime.strptime(e.date, DATE_FMT).date()
            if start_dt <= e_dt <= end_dt:
                total += e.amount
        return total


class BudgetManager:
    """Manages income, savings goal, categories, persistence, and visualization."""

    def __init__(self: "BudgetManager") -> None:
        self.monthly_income: float = 0.0
        # This value represents the user's monthly savings goal.
        self.savings_goal: float = 0.0
        self.custom_incomes: List[IncomePeriod] = []
        self.categories: Dict[str, BudgetCategory] = {}
        self.load_data()

    # Income

    def set_monthly_income(self: "BudgetManager", income: float) -> None:
        """Set the user's monthly income."""
        self.monthly_income = income

    def add_custom_income(self: "BudgetManager", amount: float, start_date: str, end_date: str) -> IncomePeriod:
        """Add income for a custom date range (inclusive)."""
        income = IncomePeriod(amount=amount, start_date=start_date, end_date=end_date)
        self.custom_incomes.append(income)
        return income

    def income_for_range(self: "BudgetManager", start_date: str, end_date: str) -> float:
        """
        Return income for a custom range by summing any custom income periods
        that overlap the selected range.

        Note: This is a simple overlap-based approach appropriate for a
        foundational course (no pro-rating).
        """
        start_dt = datetime.strptime(start_date, DATE_FMT).date()
        end_dt = datetime.strptime(end_date, DATE_FMT).date()

        total = 0.0
        for inc in self.custom_incomes:
            inc_start = datetime.strptime(inc.start_date, DATE_FMT).date()
            inc_end = datetime.strptime(inc.end_date, DATE_FMT).date()
            overlaps = not (inc_end < start_dt or inc_start > end_dt)
            if overlaps:
                total += inc.amount
        return total

    # Savings goal

    def set_savings_goal(self: "BudgetManager", goal: float) -> None:
        """Set the user's monthly savings goal."""
        self.savings_goal = goal

    # Expenses

    def add_expense(self: "BudgetManager", category_name: str, amount: float, description: str, expense_date: str) -> Expense:
        """Create and store a new expense."""
        normalized = category_name.strip().title()
        if normalized not in self.categories:
            self.categories[normalized] = BudgetCategory(normalized)

        exp = Expense(
            category=normalized,
            amount=amount,
            description=description.strip(),
            date=expense_date,
        )
        self.categories[normalized].add_expense(exp)
        return exp

    def total_expenses(
        self: "BudgetCategory",
        month: Optional[str] = None,
        date_range: Optional[Tuple[str, str]] = None,
    ) -> float:
        """Return total expenses across all categories (optionally filtered)."""
        return sum(cat.total_expenses(month=month, date_range=date_range) for cat in self.categories.values())

    # Reporting helpers

    def savings_amount_for_month(self: "BudgetManager", month: Optional[str] = None) -> float:
        """Savings for a month is monthly_income - total expenses for that month."""
        expenses = self.total_expenses(month=month) if month else self.total_expenses()
        return max(0.0, self.monthly_income - expenses)

    def savings_amount_for_range(self: "BudgetManager", start_date: str, end_date: str) -> float:
        """Savings for a custom range is income_for_range - total expenses in the range."""
        income = self.income_for_range(start_date, end_date)
        expenses = self.total_expenses(date_range=(start_date, end_date))
        return max(0.0, income - expenses)

    def progress_toward_goal(self: "BudgetManager", month: Optional[str] = None) -> Dict[str, object]:
        """Monthly goal progress (uses monthly income and month-based expense totals)."""
        savings = self.savings_amount_for_month(month)
        goal = self.savings_goal
        on_track = savings >= goal if goal > 0 else True
        remaining = max(0.0, goal - savings)
        return {"savings": savings, "goal": goal, "on_track": on_track, "remaining_needed": remaining}

    # Persistence

    def save_data(self: "BudgetManager") -> None:
        """Persist budget data to JSON."""
        data = {
            "monthly_income": self.monthly_income,
            "savings_goal": self.savings_goal,
            "custom_incomes": [ci.to_dict() for ci in self.custom_incomes],
            "categories": {
                name: [exp.to_dict() for exp in cat.expenses]
                for name, cat in self.categories.items()
            },
        }
        try:
            DATA_FILE.write_text(json.dumps(data, indent=2), encoding="utf-8")
        except OSError as exc:
            print(f"Error: Unable to save data. Details: {exc}")

    def load_data(self: "BudgetManager") -> None:
        """Load budget data from JSON file (if present)."""
        if not DATA_FILE.exists():
            return

        try:
            raw = json.loads(DATA_FILE.read_text(encoding="utf-8"))
            self.monthly_income = float(raw.get("monthly_income", raw.get("income", 0.0)))
            self.savings_goal = float(raw.get("savings_goal", 0.0))

            self.custom_incomes = []
            for item in raw.get("custom_incomes", []):
                self.custom_incomes.append(IncomePeriod.from_dict(item))

            self.categories = {}
            for name, expense_dicts in raw.get("categories", {}).items():
                cat = BudgetCategory(name)
                for exp_dict in expense_dicts:
                    cat.add_expense(Expense.from_dict(exp_dict))
                self.categories[name] = cat

        except (OSError, json.JSONDecodeError, KeyError, ValueError) as exc:
            print(f"Warning: Saved data could not be loaded. Starting fresh. ({exc})")
            self.monthly_income = 0.0
            self.savings_goal = 0.0
            self.custom_incomes = []
            self.categories = {}

    # Visualization

    def visualize_expenses(self: "BudgetManager", month: Optional[str] = None, date_range: Optional[Tuple[str, str]] = None) -> None:
        """Show a pie chart of spending by category for a selected month or custom range."""
        totals: Dict[str, float] = {}
        for name, cat in self.categories.items():
            total = cat.total_expenses(month=month, date_range=date_range)
            if total > 0:
                totals[name] = total

        if not totals:
            print("No expenses found for visualization.")
            return

        labels = list(totals.keys())
        values = list(totals.values())

        if month:
            title = f"Spending by Category ({month})"
        elif date_range:
            title = f"Spending by Category ({date_range[0]} to {date_range[1]})"
        else:
            title = "Spending by Category (All Time)"

        plt.figure()
        plt.pie(values, labels=labels, autopct="%1.1f%%")
        plt.title(title)
        plt.show()


# Input validation functions.

def get_valid_float(prompt: str, min_value: float = 0.0) -> float:
    """Prompt until the user enters a valid float >= min_value."""
    while True:
        raw = input(prompt).strip()
        try:
            value = float(raw)
            if value < min_value:
                print(f"Please enter a number greater than or equal to {min_value}.")
                continue
            if value > 1e12:
                print("That number is too large. Please enter a smaller amount.")
                continue
            return value
        except ValueError:
            print("Invalid input. Please enter a numeric value (example: 123.45).")


def get_valid_date(prompt: str) -> str:
    """Prompt until the user enters a valid date in YYYY-MM-DD format."""
    while True:
        raw = input(prompt).strip()
        try:
            datetime.strptime(raw, DATE_FMT)
            return raw
        except ValueError:
            print("Invalid date. Please use YYYY-MM-DD (example: 2026-01-11).")


def get_valid_month(prompt: str) -> str:
    """Prompt until the user enters a valid month in YYYY-MM format."""
    while True:
        raw = input(prompt).strip()
        try:
            datetime.strptime(raw + "-01", "%Y-%m-%d")
            return raw
        except ValueError:
            print("Invalid month format. Please use YYYY-MM (example: 2026-01).")


def get_valid_date_range(_unused: int = 0) -> Tuple[str, str]:
    """Prompt for a valid (start_date, end_date) range (inclusive)."""
    start = get_valid_date("Enter start date (YYYY-MM-DD): ")
    end = get_valid_date("Enter end date (YYYY-MM-DD): ")

    start_dt = datetime.strptime(start, DATE_FMT).date()
    end_dt = datetime.strptime(end, DATE_FMT).date()
    if end_dt < start_dt:
        print("End date cannot be before start date. Dates were swapped automatically.")
        return end, start
    return start, end


# Main program loop.

def main(_unused: int = 0) -> None:
    manager = BudgetManager()

    print("Welcome to Personal Budgeting Application!")

    while True:
        print("\nMenu:")
        print("1. Set Income (Monthly or Custom Timeframe)")
        print("2. Set Monthly Savings Goal")
        print("3. Add Expense")
        print("4. View Total Expenses (Month or Custom Period)")
        print("5. View Savings Progress (Month or Custom Period)")
        print("6. Visualize Expenses (Month or Custom Period)")
        print("7. Save & Exit")

        choice = input("Choose an option (1-7): ").strip()

        if choice == "1":
            print("\nIncome Options:")
            print("1) Set Monthly Income")
            print("2) Add Custom Timeframe Income")
            sub = input("Choose (1-2): ").strip()

            if sub == "1":
                income = get_valid_float("Enter your monthly income: $", min_value=0.0)
                manager.set_monthly_income(income)
                print(f"Monthly income set to ${manager.monthly_income:,.2f}")

            elif sub == "2":
                amount = get_valid_float("Enter income amount for the custom period: $", min_value=0.0)
                print("Enter the custom income period:")
                start_date, end_date = get_valid_date_range()
                inc = manager.add_custom_income(amount, start_date, end_date)
                print(f"Added custom income: ${inc.amount:,.2f} for {inc.start_date} to {inc.end_date}")
            else:
                print("Invalid selection. Returning to main menu.")

        elif choice == "2":
            goal = get_valid_float("Enter your monthly savings goal: $", min_value=0.0)
            manager.set_savings_goal(goal)
            print(f"Monthly savings goal set to ${manager.savings_goal:,.2f}")

        elif choice == "3":
            category = input("Enter expense category (e.g., Housing, Food): ").strip()
            if not category:
                print("Category cannot be blank.")
                continue

            # Disallow $0 expenses to keep entries meaningful.
            amount = get_valid_float("Enter expense amount: $", min_value=0.01)

            description = input("Enter a brief description: ").strip() or "No description provided"
            expense_date = get_valid_date("Enter expense date (YYYY-MM-DD): ")

            exp = manager.add_expense(category, amount, description, expense_date)
            print(f"Added expense: {exp.category} - ${exp.amount:,.2f} ({exp.description}) on {exp.date}")

        elif choice == "4":
            print("\nExpense Report Options:")
            print("1) Specific Month (YYYY-MM)")
            print("2) Custom Period (start/end dates)")
            print("3) All Time")
            sub = input("Choose (1-3): ").strip()

            if sub == "1":
                month = get_valid_month("Enter month (YYYY-MM): ")
                total = manager.total_expenses(month=month)
                print(f"Total expenses ({month}): ${total:,.2f}")
            elif sub == "2":
                start_date, end_date = get_valid_date_range()
                total = manager.total_expenses(date_range=(start_date, end_date))
                print(f"Total expenses ({start_date} to {end_date}): ${total:,.2f}")
            elif sub == "3":
                total = manager.total_expenses()
                print(f"Total expenses (All Time): ${total:,.2f}")
            else:
                print("Invalid selection. Returning to main menu.")

        elif choice == "5":
            print("\nSavings Report Options:")
            print("1) Specific Month (uses monthly income)")
            print("2) Custom Period (uses custom income periods)")
            sub = input("Choose (1-2): ").strip()

            if sub == "1":
                month = get_valid_month("Enter month (YYYY-MM): ")
                info = manager.progress_toward_goal(month=month)
                savings = float(info["savings"])
                goal = float(info["goal"])
                on_track = bool(info["on_track"])
                remaining = float(info["remaining_needed"])

                if goal <= 0:
                    print(f"Estimated savings for {month}: ${savings:,.2f}. No monthly savings goal set yet.")
                elif on_track:
                    print("You are on track!")
                    print(f"Estimated savings for {month}: ${savings:,.2f} (Goal: ${goal:,.2f})")
                else:
                    print(f"Estimated savings for {month}: ${savings:,.2f}")
                    print(f"You need ${remaining:,.2f} to reach your goal of ${goal:,.2f}.")

            elif sub == "2":
                start_date, end_date = get_valid_date_range()
                income = manager.income_for_range(start_date, end_date)
                expenses = manager.total_expenses(date_range=(start_date, end_date))
                savings = max(0.0, income - expenses)
                print(f"Custom-period income (overlapping entries): ${income:,.2f}")
                print(f"Custom-period expenses: ${expenses:,.2f}")
                print(f"Estimated savings ({start_date} to {end_date}): ${savings:,.2f}")
            else:
                print("Invalid selection. Returning to main menu.")

        elif choice == "6":
            print("\nVisualization Options:")
            print("1) Specific Month (YYYY-MM)")
            print("2) Custom Period (start/end dates)")
            print("3) All Time")
            sub = input("Choose (1-3): ").strip()

            if sub == "1":
                month = get_valid_month("Enter month (YYYY-MM): ")
                manager.visualize_expenses(month=month)
            elif sub == "2":
                start_date, end_date = get_valid_date_range()
                manager.visualize_expenses(date_range=(start_date, end_date))
            elif sub == "3":
                manager.visualize_expenses()
            else:
                print("Invalid selection. Returning to main menu.")

        elif choice == "7":
            manager.save_data()
            print("Data saved successfully. Exiting the program.")
            break

        else:
            print("Invalid choice. Please try again.")


if __name__ == "__main__":
    main()
