# 7-2 Activity: Building a Simple Calculator

#Show a menu of operations until the user decides to exit
while True:
    print("\nCalculator")
    print("1) Addition")
    print("2) Subtraction")
    print("3) Multiplication")
    print("4) Division")
    print("0) Exit")

    #Get user choice and strip whitespace
    choice = input("Enter your choice (0-4): ").strip()

    #Exit if user chooses 0
    if choice == "0":
        print("Goodbye!")
        break

    #Validate menu choice
    if choice not in ["1", "2", "3", "4"]:
        print("Invalid selection. Please try again.")
        #If input is invalid restart the loop and show the menu again
        continue

    #Get first number and ensure it's a valid float
    try:
        num1 = float(input("Enter the first number: "))
    except ValueError:
        print("Invalid number. Please enter a numeric value.")
        continue

    #Get second number and ensure it's a valid float
    try:
        num2 = float(input("Enter the second number: "))
    except ValueError:
        print("Invalid number. Please enter a numeric value.")
        continue

    #Division by zero check for division operation
    if choice == "4" and num2 == 0:
        print("Error: Cannot divide by zero.")
    else:
        #Perform calculation
        if choice == "1":
            result = num1 + num2
        elif choice == "2":
            result = num1 - num2
        elif choice == "3":
            result = num1 * num2
        else:  #choice == "4"
            result = num1 / num2

        print(f"Result: {result:g}")

    #Continue or exit remove whitespace and convert to lowercase
    again = input("Another calculation? (y/n): ").strip().lower()
    if again != "y":
        print("Goodbye!")
        break